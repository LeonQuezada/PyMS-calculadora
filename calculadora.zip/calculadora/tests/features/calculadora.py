class calculadora:
	def suma(self,num1,num2):
		return num1 + num2